package com.example.thehistoryproject

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       val editAge = findViewById<TextView>(R.id.editAge)
       val editText = findViewById<TextView>(R.id.textView4)
       val button1 = findViewById<Button>(R.id.button1)
       val button2 = findViewById<Button>(R.id.button2)
        button2.setOnClickListener {
            editText.text=""

        }

         button1.setOnClickListener {
               val age = editAge.text.toString().toInt()


                   if (age in 1..20) {

                       // you match the Age of Cameron Boyce, who was Best known for his roles in Disney Channel's hit shows like "Jessie" and the "Descendants" movie franchise,Tragically, Boyce passed away in 2019 at a young age, leaving behind a legacy of kindness, talent, and inspiration.
                   } else if (age == 34) {
                       // Output ".text = 'thirty-four'"
                          editText.text="RIKY RICK,Multi-talented entertainer most well known as a rapper, but also skilled as an actor, writer, and producer. He put out a debut studio album called Family Values in April of 2015 which was certified gold. He died at the young age of 34."
                   } else {
                       // Check for specific numbers
                       if (age == 57) {
                           editText.text="Prince Rogers Nelson, this acclaimed recording artist released ten platinum-selling albums. He also won multiple Grammy Awards for the hit song Purple Rain, including Best Performance and Best Soundtrack."
                       }
                       if (age == 67) {
                           editText.text="LYNJA a TikTok Star,Fun-loving and comedic content creator who focused on food and cooking. Her videos made fun of traditional cooking content and traditional skills, but she also offered up food that was appealing and easy to make, like scallion pancakes or sweet and salty roasted nuts. She sometimes posted non-recipes, like bananas with mayo. Her wildly entertaining cookingwithlynja TikTok account attracted over 20 million fans and garnered 308 million likes. "
                       }
                       if (age == 69) {
                           editText.text="ELIZABETH I OF ENGLAND,The Virgin Queen who, during her reign from 1558 to 1603, saw England thrive politically and culturally in an era known as the Elizabethan era. She came to power after the death of her half-sister Mary I, who had previously kept her imprisoned for a year. "
                       }
                       if (age == 38) {
                           editText.text="John F Kennedy Jr was the son of former US President John F Kennedy. He tragically died at a young age of 38 when the plane he was flying crashed into the Atlantic Ocean off Martha's Vineyard, Massachusetts in 1999. He was a lawyer and a journalist and had founded the trendy political magazine, George, which stopped publication in 2001.   "
                       }
                       if (age == 56) {
                           editText.text=" STEVE JOBS,Led the personal computer revolution by co-founding Apple with Steve Wozniak. During his time as CEO of Apple, the company released such revolutionary devices as the iMac, iPod, iPhone and iPad. He also founded the software company NeXT and was a chairman for Pixar and a member of The Walt Disney Company's board of directors."
                       }
                       if (age == 39) {
                           editText.text="MARTIN LUTHER KING JR.African-American Civil Rights Movement leader and clergyman who used civil disobedience to combat institutionalized racism. He is remembered best for his iconic I Have A Dream Speech, which he gave in front of the Lincoln Memorial during the 1963 March on Washington. He received the Nobel Peace Prize in 1964."
                       }
                       if (age == 90) {
                           editText.text = "ENZO FERRARI,born on February 20, 1898, in Modena, Italy, was a visionary entrepreneur and racing driver who founded one of the most iconic luxury sports car manufacturers in the world: Ferrari. His name has become synonymous with excellence, speed, and passion for automobiles.Enzo Ferrari passed away on August 14, 1988, but his spirit lives on through the timeless legacy of the Ferrari brand, which remains a symbol of elegance, speed, and the pursuit of automotive excellence."
                       }
                       if (age == 28) {
                           editText.text= "AVICII, Grammy award-nominated Swedish DJ and remixer who became known for international hits such as Levels,Hey Brother, and Wake Me Up. he tragically passed away at the age of 28"
                       }
                       // Add more if statement if you need age
                   }
           }
























                   }
           }









